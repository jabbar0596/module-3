package com.cg.pl;

import java.util.Scanner;

import com.cg.bean.Book;
import com.cg.exception.BookException;
import com.cg.service.BookCollectionHelper;
import com.cg.service.BookValidater;


public class BookMain {

	static Scanner scan = new Scanner(System.in);
	static BookValidater val = new BookValidater();
	static BookMain bookmain=new BookMain();
	static Book book;
    static String	id;
    static String	name;
    static String	price;
	public static void main(String[] args) {
		
		bookmain.menu();

	}


	public void menu() {
		
		int ch = 0;
		System.out.println("1.To add new Book Details");
		System.out.println("2.To get total number of Books");
		System.out.println("3.Exit");
		System.out.println("Enter your choice : ");
        ch=scan.nextInt();
        
		switch (ch)
		{
		case 1:
			addBookRecords();
			break;
			
		case 2:
			int count= new BookCollectionHelper().getTotalBookCount();
			System.out.println("Total number of book details are"+count);
			break;
			
		case 3:
			System.out.println("-----Exit-----");
			break;
			
		default:
			System.err.println("Please enter the correct choice");
		}
		
		System.out.println("\n\n---------------------------------");
		if(ch !=3 )
		{
		menu();
		}
	}


	public void addBookRecords() {

		System.out.println("please enter how many Book details you want to add");
		int num=scan.nextInt();

		while(num>0)
			{

		System.out.println("Enter the following details:");

		// call validate method after data accept from user


		int bookId = Integer.parseInt(acceptBookId());
		String bookName = acceptBookName();
		float bookPrice = Float.parseFloat(acceptBookPrice());

		book =new Book(bookId,bookName,bookPrice);
		
		
		new BookCollectionHelper().addBookDetail(book);

		System.out.println("Book detail added successfully");

		num--;
		}

		
		
	}


	private String acceptBookId() {
		
		System.out.println("Enter Book Id:");
        id=scan.next();
	
	try{
		val.isValidBookId(id);
		
	}
	catch(BookException exp){
		
		System.err.println(exp.getMessage());
		acceptBookId();
	}
	return id;

	}
	
	private String acceptBookName() {
		
		System.out.println("Enter Book Name:");
        name=scan.next();
	
	try{
		val.isValidBookName(name);
		
	}
	catch(BookException exp){
		
		System.err.println(exp.getMessage());
		acceptBookName();
	}
	return name;

	}

	private String acceptBookPrice() {
		
		System.out.println("Enter Book Price:");
        price=scan.next();
	
	try{
		val.isValidBookPrice(price);
		
	}
	catch(BookException exp){
		
		System.err.println(exp.getMessage());
		acceptBookPrice();
	}
	return price;

	}

}
