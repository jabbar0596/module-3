package com.cg.service;

import java.util.HashSet;
import java.util.Set;
import com.cg.bean.Book;


public class BookCollectionHelper {

	
	private static Set<Book> obj;
	
	static Book book;
	
	static{
		obj=new HashSet<>();
	
		//adding 5 books details in static block
		book = new Book(101,"Sea of C",350.00f);
		obj.add(book);
		
		book = new Book(102,"Java for Beginner",200.00f);
		obj.add(book);
		
		book = new Book(103,"Learn Java in 21 Days",350.00f);
		obj.add(book);
		
		book = new Book(104,"Learn .Net with C# in 21 Days",350.00f);
		obj.add(book);
		
		book = new Book(101,"C++ Programming for Beginners",350.00f);
		obj.add(book);
	}

	public static Set<Book> getObj() {
		return obj;
	}

	public static void setObj(Set<Book> obj) {
		BookCollectionHelper.obj = obj;
	}

	public static Book getBook() {
		return book;
	}

	public static void setBook(Book book) {
		BookCollectionHelper.book = book;
	}

	public void addBookDetail(Book book){
		
		obj.add(book);
		
	}
	
	public int getTotalBookCount(){
		return obj.size();
	}
	
}
