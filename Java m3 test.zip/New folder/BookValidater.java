package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.exception.BookException;

public class BookValidater {

	// implement each validateMethod
	public boolean isValidBookId(String bookId)throws BookException{
		boolean flag=false;

		
		Pattern pat = Pattern.compile("^[0-9]{3}$");
		Matcher mat= pat.matcher(bookId);
		if(!mat.find()){
			
			throw new BookException("Error:Book should be three digits format only");
			
		}
		
		return flag;

	}
	
	
	public boolean isValidBookName(String bookName)throws BookException{
		boolean flag=false;

		
		Pattern pat = Pattern.compile("^[A-Za-z0-9]{5,20}$");
		Matcher mat= pat.matcher(bookName);
		if(!mat.find()){
			
			throw new BookException("Error:Book name should be alphanumeric format");
			
		}
		
		return flag;

	}

	public boolean isValidBookPrice(String bookPrice)throws BookException{
		boolean flag=false;

		
		Pattern pat = Pattern.compile("^[0-9]{3}.[0-9]{0,2}$");
		Matcher mat= pat.matcher(bookPrice);
		if(!mat.find()){
			
			throw new BookException("Error:Book price should be in float(decimal) format only\n enter only three whole digits");
			
		}
	
		if(Float.parseFloat(bookPrice) > 1000.00f){
			
			throw new BookException("Error:Book price should not be more than 1000Rs");
			
		}
		
		return flag;

	}

	
	
}
